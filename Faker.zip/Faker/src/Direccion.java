
public class Direccion {
	public String calle;
	public String ciudad;
	public String estado;
	public String pais;
}
